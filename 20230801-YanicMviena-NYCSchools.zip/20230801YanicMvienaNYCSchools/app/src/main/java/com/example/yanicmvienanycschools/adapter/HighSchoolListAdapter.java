package com.example.yanicmvienanycschools.adapter;


import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.yanicmvienanycschools.data.HighSchool;
import com.example.yanicmvienanycschools.databinding.ListItemSchoolBinding;

import java.util.List;

public class HighSchoolListAdapter extends RecyclerView.Adapter<HighSchoolListAdapter.ViewHolder> {
    private final List<HighSchool> highSchoolList;
    private final OnItemClickListener onItemClickListener;

    public HighSchoolListAdapter(List<HighSchool> highSchoolList,OnItemClickListener onItemClickListener) {
        this.highSchoolList = highSchoolList;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ListItemSchoolBinding binding = ListItemSchoolBinding.inflate(inflater, parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(highSchoolList.get(position),onItemClickListener);
    }

    @Override
    public int getItemCount() {
        return highSchoolList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ListItemSchoolBinding listItemSchoolBinding;

        public ViewHolder(ListItemSchoolBinding listItemSchoolBinding) {
            super(listItemSchoolBinding.getRoot());
            this.listItemSchoolBinding = listItemSchoolBinding;
        }

        public void bind(HighSchool dataModel,OnItemClickListener onItemClickListener) {
            listItemSchoolBinding.nameText.setText(dataModel.getSchoolName());
            listItemSchoolBinding.city.setText(dataModel.getCity());
            // Bind other views using View Binding
            listItemSchoolBinding.getRoot().setOnClickListener(view -> {
                onItemClickListener.onItemClick(getAdapterPosition());
            });
        }

    }

    public interface OnItemClickListener{
        public void onItemClick(int position);
    }
}
