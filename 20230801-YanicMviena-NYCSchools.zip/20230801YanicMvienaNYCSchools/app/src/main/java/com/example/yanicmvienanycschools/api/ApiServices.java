package com.example.yanicmvienanycschools.api;


import com.example.yanicmvienanycschools.data.HighSchool;
import com.example.yanicmvienanycschools.data.SatScore;

import java.util.List;

import io.reactivex.rxjava3.core.Observable;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiServices {
    @GET("resource/s3k6-pzi2.json")
    Observable<List<HighSchool>> getHighSchoolsList();

    @GET("resource/f9bf-2cp4.json")
    Observable<List<SatScore>> getSatScore(@Query("dbn") String dbn);

}
