package com.example.yanicmvienanycschools.repository;


import com.example.yanicmvienanycschools.api.ApiServices;
import com.example.yanicmvienanycschools.data.HighSchool;
import com.example.yanicmvienanycschools.data.SatScore;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.rxjava3.core.Observable;

public class ApiRepository {

    private ApiServices apiServices;

    @Inject
    public ApiRepository(ApiServices apiServices) {
        this.apiServices = apiServices;
    }


    public Observable<List<HighSchool>> getHighSchools(){
        return apiServices.getHighSchoolsList();
    }

    public Observable<List<SatScore>> getSatScore(String dbn){
        return apiServices.getSatScore(dbn);
    }

}
