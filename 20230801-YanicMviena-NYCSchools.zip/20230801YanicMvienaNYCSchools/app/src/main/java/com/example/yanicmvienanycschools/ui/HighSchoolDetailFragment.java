package com.example.yanicmvienanycschools.ui;

import static com.example.yanicmvienanycschools.utils.Constants.KEY_DBN;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.yanicmvienanycschools.R;
import com.example.yanicmvienanycschools.data.SatScore;
import com.example.yanicmvienanycschools.databinding.FragmentHighSchoolDetailBinding;
import com.example.yanicmvienanycschools.utils.APIResponse;
import com.example.yanicmvienanycschools.viewmodel.HighSchoolDetailViewModel;

import java.util.List;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HighSchoolDetailFragment extends Fragment {
    private static final String TAG = "HighSchoolDetail";
    private FragmentHighSchoolDetailBinding binding;
    private HighSchoolDetailViewModel highSchoolDetailViewModel;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        highSchoolDetailViewModel =
                new ViewModelProvider(this).get(HighSchoolDetailViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentHighSchoolDetailBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        highSchoolDetailViewModel.getUiState().observe(getViewLifecycleOwner(), apiResponse -> {
            if (apiResponse instanceof APIResponse.Loading) {
                binding.satGroup.setVisibility(View.GONE);
                binding.errorText.setVisibility(View.GONE);
                binding.progressBar.setVisibility(View.VISIBLE);
            } else if (apiResponse instanceof APIResponse.Success) {
                binding.satGroup.setVisibility(View.VISIBLE);
                binding.errorText.setVisibility(View.GONE);
                binding.progressBar.setVisibility(View.GONE);
                List<SatScore> satScoreList =
                        (List<SatScore>) ((APIResponse.Success<?>) apiResponse).getValue();
                if (satScoreList != null && !satScoreList.isEmpty()) {
                    binding.nameText.setText(satScoreList.get(0).getSchoolName());
                    binding.mathSatScore.setText(getString(R.string.sat_math_avg_score,
                            satScoreList.get(0).getSatMathAvgScore()));
                    binding.readingSatScore.setText(getString(R.string.sat_critical_reading_avg_score, satScoreList.get(0).getSatCriticalReadingAvgScore()));
                    binding.writingSatScore.setText(getString(R.string.sat_writing_avg_score,
                            satScoreList.get(0).getSatWritingAvgScore()));
                } else {
                    binding.satGroup.setVisibility(View.GONE);
                    binding.errorText.setVisibility(View.VISIBLE);
                }

            } else {
                binding.satGroup.setVisibility(View.GONE);
                binding.errorText.setVisibility(View.VISIBLE);
                binding.progressBar.setVisibility(View.GONE);
            }
        });
        Bundle args = getArguments();
        Log.i(TAG, "onViewCreated: " + args);
        if (args != null) {
            String dbn = args.getString(KEY_DBN, "");
            Log.i(TAG, "onViewCreated: " + dbn);
            if (!dbn.isEmpty()) {
                highSchoolDetailViewModel.getSatScore(dbn);
            }
        }
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}