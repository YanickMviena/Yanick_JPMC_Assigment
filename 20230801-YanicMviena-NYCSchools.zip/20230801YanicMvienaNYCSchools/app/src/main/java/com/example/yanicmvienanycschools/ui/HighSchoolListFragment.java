package com.example.yanicmvienanycschools.ui;

import static com.example.yanicmvienanycschools.utils.Constants.KEY_DBN;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;

import com.example.yanicmvienanycschools.R;
import com.example.yanicmvienanycschools.adapter.HighSchoolListAdapter;
import com.example.yanicmvienanycschools.data.HighSchool;
import com.example.yanicmvienanycschools.databinding.FragmentHighSchoolListBinding;
import com.example.yanicmvienanycschools.utils.APIResponse;
import com.example.yanicmvienanycschools.viewmodel.HighSchoolListViewModel;

import java.util.ArrayList;
import java.util.List;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HighSchoolListFragment extends Fragment implements HighSchoolListAdapter.OnItemClickListener {

    private static final String TAG = "FirstFragment";

    private FragmentHighSchoolListBinding binding;

    private HighSchoolListViewModel highSchoolListViewModel;

    private final List<HighSchool> highSchoolList = new ArrayList<>();
    private HighSchoolListAdapter highSchoolListAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        highSchoolListViewModel = new ViewModelProvider(this).get(HighSchoolListViewModel.class);
        highSchoolListViewModel.getHighSchoolList();
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentHighSchoolListBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        highSchoolListAdapter = new HighSchoolListAdapter(highSchoolList,this);
        binding.recyclerView.setHasFixedSize(true);
        binding.recyclerView.setAdapter(highSchoolListAdapter);

        highSchoolListViewModel.getUiState().observe(getViewLifecycleOwner(), apiResponse -> {

            if (apiResponse instanceof APIResponse.Loading) {
                Log.i(TAG, "onViewCreated: Loading ");
                binding.recyclerView.setVisibility(View.GONE);
                binding.errorText.setVisibility(View.GONE);
                binding.progressBar.setVisibility(View.VISIBLE);
            } else if (apiResponse instanceof APIResponse.Success) {
                List<HighSchool> list =
                        (List<HighSchool>) ((APIResponse.Success<?>) apiResponse).getValue();
                highSchoolList.addAll(list);
                highSchoolListAdapter.notifyDataSetChanged();
                binding.recyclerView.setVisibility(View.VISIBLE);
                binding.errorText.setVisibility(View.GONE);
                binding.progressBar.setVisibility(View.GONE);
            } else {
                Log.i(TAG, "onViewCreated: " + apiResponse.toString());
                binding.recyclerView.setVisibility(View.GONE);
                binding.errorText.setVisibility(View.VISIBLE);
                binding.progressBar.setVisibility(View.GONE);
            }


        });

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onItemClick(int position) {
        Bundle args = new Bundle();
        args.putString(KEY_DBN, highSchoolList.get(position).getDbn());
        NavHostFragment.findNavController(HighSchoolListFragment.this)
                .navigate(R.id.action_FirstFragment_to_SecondFragment,args);
    }
}