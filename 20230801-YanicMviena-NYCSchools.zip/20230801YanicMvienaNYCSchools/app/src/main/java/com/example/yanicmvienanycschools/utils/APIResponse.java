package com.example.yanicmvienanycschools.utils;


public abstract class APIResponse {
   private APIResponse() {}

   public static final class Loading extends APIResponse {}

   public static final class Success<T> extends APIResponse {
      private final T value;

      public Success(T value) {
         this.value = value;
      }

      public T getValue() {
         return value;
      }
   }
   public static final class Error<T> extends APIResponse {
      private final T value;

      public Error(T value) {
         this.value = value;
      }

      public T getValue() {
         return value;
      }
   }
}
