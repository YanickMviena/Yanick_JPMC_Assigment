package com.example.yanicmvienanycschools.utils;


public class Constants {
   public static final String BASE_URL = "https://data.cityofnewyork.us/";
   public static final String KEY_DBN = "dbn";
}
