package com.example.yanicmvienanycschools.viewmodel;


import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.yanicmvienanycschools.repository.ApiRepository;
import com.example.yanicmvienanycschools.utils.APIResponse;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.schedulers.Schedulers;

@HiltViewModel
public class HighSchoolDetailViewModel extends ViewModel {

    private final MutableLiveData<APIResponse> uiState = new MutableLiveData<>();

    public LiveData<APIResponse> getUiState() {
        return uiState;
    }

    private final ApiRepository apiRepository;

    @Inject
    public HighSchoolDetailViewModel(ApiRepository apiRepository) {
        this.apiRepository = apiRepository;
    }

    public void getSatScore(String dbn) {
        uiState.postValue(new APIResponse.Loading());
        apiRepository.getSatScore(dbn)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(satScore -> uiState.postValue(new APIResponse.Success(satScore))
                        , throwable -> uiState.postValue(new APIResponse.Error(throwable)));
    }
}
